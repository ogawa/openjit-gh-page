/* Version number of JDK */
#undef JDK_VERSION

#undef PACKAGE

#undef VERSION

#undef SYM_UNDERSCORE

#undef ATTRIB_BEFORE_FUNC
