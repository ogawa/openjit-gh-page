/*
 * Copyright (c) 1999-2001
 * Information Promotion Agency of Japan (IPA),
 * Fujitsu Limited, and 
 * Matsuoka Laboratory, Tokyo Institute of Technology
 * All rights reserved.
 *
 * Redistribution and non-commercial use in source and binary forms, 
 * with or without modification, are permitted provided that the following 
 * conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this 
 *    software must display the following acknowledgement:
 *
 *    This product includes software developed by Information Promotion Agency
 *    of Japan, Fujitsu Limited, and Matsuoka Laboratory, 
 *    Tokyo Institute of Technology.
 *
 * 4. The names "Information Promotion Agency", "Fujitsu Limited",
 *    "Matsuoka Laboratory", or "Tokyo Institute of Technology" should
 *    not be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * 5. Any use of the source code or the binary in a commercial product, 
 *    whether may it be the origial representation or in some modified form,
 *    is not permitted without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * $Revision: 1.5 $
 * $Date: 2000/03/15 03:04:28 $
 * $Author: kouya $
 */

#include "OpenJIT.h"

#if JDK_VERSION >= 12

#define ASM __asm__ volatile

#if defined(sparc)
#define DEFLINK(FUNC)				\
do {						\
    ASM(".globl " #FUNC);			\
    ASM(".type " #FUNC ",#function");		\
    ASM(".weak " #FUNC);			\
    ASM(#FUNC ":");				\
    ASM("save %sp, -112, %sp");			\
    ASM("jmp %0" : : "r"(jit_link->FUNC));	\
    ASM("restore");				\
} while(0)
#elif defined(i386)
#define DEFLINK(FUNC)				\
do {						\
    register JITlink const *p __asm__("%eax");	\
    ASM(".globl " #FUNC);			\
    ASM(".type " #FUNC ",@function");		\
    ASM(".weak " #FUNC);			\
    ASM(#FUNC ":");				\
    p = jit_link;				\
    ASM("jmp *%0" : : "m" (p->FUNC));		\
} while(0)
#endif

static void dummy()
{
#ifdef HAVE_EE
    DEFLINK(EE);
#endif
#ifdef HAVE_EXPANDJAVASTACK
    DEFLINK(ExpandJavaStack);
#endif
#ifdef HAVE_EXPANDJAVASTACKFORJNI
    DEFLINK(ExpandJavaStackForJNI);
#endif
#ifdef HAVE_INITCLASS
    DEFLINK(InitClass);
#endif
#ifdef HAVE_MULTIARRAYALLOC
    DEFLINK(MultiArrayAlloc);
#endif
#ifdef HAVE_RESOLVECLASSCONSTANT2
    DEFLINK(ResolveClassConstant2);
#endif
#ifdef HAVE_RESOLVECLASSCONSTANTFROMCLASS2
    DEFLINK(ResolveClassConstantFromClass2);
#endif
#ifdef HAVE_SIGNALERROR
    DEFLINK(SignalError);
#endif
#ifdef HAVE_VERIFYCLASSACCESS
    DEFLINK(VerifyClassAccess);
#endif
#ifdef HAVE_ALLOCARRAY
    DEFLINK(allocArray);
#endif
#ifdef HAVE_ALLOCOBJECT
    DEFLINK(allocObject);
#endif
#ifdef HAVE_DO_EXECUTE_JAVA_METHOD_VARARG
    DEFLINK(do_execute_java_method_vararg);
#endif
#ifdef HAVE_INVOKEJAVAMETHOD
    DEFLINK(invokeJavaMethod);
#endif
#ifdef HAVE_INVOKESYNCHRONIZEDJAVAMETHOD
    DEFLINK(invokeSynchronizedJavaMethod);
#endif
#ifdef HAVE_IS_INSTANCE_OF
    DEFLINK(is_instance_of);
#endif
#ifdef HAVE_JIO_SNPRINTF
    DEFLINK(jio_snprintf);
#endif
#ifdef HAVE_MONITORENTER2
    DEFLINK(monitorEnter2);
#endif
#ifdef HAVE_MONITOREXIT2
    DEFLINK(monitorExit2);
#endif
#ifdef HAVE_SYSFREE
    DEFLINK(sysFree);
#endif
#ifdef HAVE_SYSMALLOC
    DEFLINK(sysMalloc);
#endif
#ifdef HAVE_SYSMONITORENTER
    DEFLINK(sysMonitorEnter);
#endif
#ifdef HAVE_SYSMONITOREXIT
    DEFLINK(sysMonitorExit);
#endif
#ifdef HAVE_SYSREALLOC
    DEFLINK(sysRealloc);
#endif

    /* shut up warning of gcc !!! */
    dummy();
}

#endif
