/*
 * Copyright (c) 1999-2001
 * Information Promotion Agency of Japan (IPA),
 * Fujitsu Limited, and 
 * Matsuoka Laboratory, Tokyo Institute of Technology
 * All rights reserved.
 *
 * Redistribution and non-commercial use in source and binary forms, 
 * with or without modification, are permitted provided that the following 
 * conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this 
 *    software must display the following acknowledgement:
 *
 *    This product includes software developed by Information Promotion Agency
 *    of Japan, Fujitsu Limited, and Matsuoka Laboratory, 
 *    Tokyo Institute of Technology.
 *
 * 4. The names "Information Promotion Agency", "Fujitsu Limited",
 *    "Matsuoka Laboratory", or "Tokyo Institute of Technology" should
 *    not be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * 5. Any use of the source code or the binary in a commercial product, 
 *    whether may it be the origial representation or in some modified form,
 *    is not permitted without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * $Revision: 1.24 $
 * $Date: 2000/04/03 02:43:55 $
 * $Author: kouya $
 */

#include "platform.h"

#include "bool.h"
#include "memory.h"
#include "oobj.h"
#include "interpreter.h"
#include "signature.h"
#include "tree.h"
#include "threads.h"
#include "exceptions.h"
#include "javaString.h"
#include "jmath.h"

#define OPENJITPKG "org/OpenJIT/"

/* support native thread. */
#define NATIVE_THREAD

/* in native thread, it might not work well? */
#define CODE_PATCH

/* resolve String at compile time for performace. */
#define RESOLVE_STRING_BEFOREHAND


struct compiled_CatchFrame {
    caddr_t start_pc, end_pc;	/* pc range of corresponding try block */
    caddr_t handler_pc;	        /* pc of catch handler */
};

/* methodblock->CompiledCodeFlags */
enum return_type {
    CCF_RETURN_VOID   = 0,
    CCF_RETURN_INT    = 1,
    CCF_RETURN_LONG   = 2,
    CCF_RETURN_FLOAT  = 3,
    CCF_RETURN_DOUBLE = 4,
};

#define RETURN_TYPE(mb)		(mb->CompiledCodeFlags & 0x7)

#define COMPILED_CODE_FLAGS_COMPILE_START	0x08
#define START_COMPILE(mb) \
	mb->CompiledCodeFlags |= COMPILED_CODE_FLAGS_COMPILE_START
#define COMPILE_ON_THE_WAY(mb) \
	((mb->CompiledCodeFlags & COMPILED_CODE_FLAGS_COMPILE_START) != 0)
#define END_COMPILE(mb) \
	mb->CompiledCodeFlags &= ~COMPILED_CODE_FLAGS_COMPILE_START
#define FIX_ENTRY(mb) \
	((unsigned char *)&(mb->CompiledCodeFlags))[1] = 0xff;
#define ENTRY_IS_FIXED(mb) \
	(((unsigned char *)&(mb->CompiledCodeFlags))[1] != 0)

/* JDK doesn't use EE arguments!!! */
#define IS_INSTANCE_OF(H, CB, EE)	is_instance_of(H, CB, NULL)

#if JDK_VERSION < 12
extern struct StrIDhash *nameTypeHash;

typedef struct {
    int *JavaVersion;

    void (**p_InitializeForCompiler)();
    void (**Vec_p_invokeCompiledMethod)();
    void (**p_CompiledCodeSignalHandler)();
    void (**p_CompilerFreeClass)();
    void (**p_CompilerCompileClass)();
    void (**p_CompilerCompileClasses)();
    void (**p_CompilerEnable)();
    void (**p_CompilerDisable)();
    void (**p_ReadInCompiledCode)();
    bool_t (**p_PCinCompiledCode)();
    unsigned char *(**p_CompiledCodePC)();
    char **p_CompiledCodeAttribute;
    bool_t *Vec_UseLosslessQuickOpcodes;

    void * (*sysMalloc)();
    void * (*sysCalloc)();
    void * (*sysRealloc)();
    void * (*sysFree)();

    ClassClass *** binclasses;
    int *nbinclasses;
    sys_mon_t **lock_classes;
    sys_mon_t **unlock_classes;

    ClassClass ** classJavaLangClass;
    ClassClass ** classJavaLangObject;
    ClassClass ** classJavaLangString;
    ClassClass ** classJavaLangThrowable;
    ClassClass ** classJavaLangException;
    ClassClass ** classJavaLangRuntimeException;
    ClassClass ** interfaceJavaLangCloneable;
    
    ExecEnv *(*EE)();
    void (*SignalError)();
    exception_t (*exceptionInternalObject)();

    char *(*GetClassConstantClassName)();
    bool_t (*ResolveClassConstant)();
    bool_t (*ResolveClassConstantFromClass)();
    bool_t (*VerifyClassAccess)();
    ClassClass *(*FindClass)();
    ClassClass *(*FindClassFromClass)();
    bool_t (*dynoLink)();
    long (*do_execute_java_method_vararg)();
    bool_t (*is_subclass_of)();
    
    bool_t (*invokeJavaMethod)();
    bool_t (*invokeSynchronizedJavaMethod)();
    bool_t (*invokeAbstractMethod)();
    bool_t (*invokeLazyNativeMethod)();
    bool_t (*invokeSynchronizedNativeMethod)();
    bool_t (*invokeCompiledMethod)();
	 
    void (*monitorEnter)();
    void (*monitorExit)();
    void (*monitorRegister)();
    int (*sysMonitorSizeof)();
    int (*sysMonitorEnter)();
    int (*sysMonitorExit)();
    
    HObject *(*ObjAlloc)();
    HObject *(*ArrayAlloc)();
    HObject *(*MultiArrayAlloc)();
    int (*sizearray)();
    HObject *(*newobject)();
    bool_t (*is_instance_of)();
    char *(*classname2string)();
    char *(*ID2Str)();
    void (*interfaceHash)();
    void (*DumpThreads)();
    
    JavaStack *(*CreateNewJavaStack)();
    long (*execute_java_static_method)();
    bool_t (*ExecuteJava)();
    
    long (*now)();
    int  *java_monitor;
    void (*java_mon)();
    long (*JavaStackSize)();
    
    JavaFrame *(**p_CompiledFramePrev)();
    int (*jio_snprintf)();
    char *(*javaString2CString)();
    
    bool_t (*dynoLinkJNI)();
    bool_t (*invokeNativeMethod)();
    
    jref (*jni_AddRefCell)();
    bool_t (*invokeJNINativeMethod)();
    bool_t (*invokeJNISynchronizedNativeMethod)();
    bool_t (*VerifyFieldAccess)();
} JITlink;

#else  /* JDK1.2 */
#include "jit.h"

typedef JITInterface6 JITlink;

#undef sysMalloc
#undef sysRealloc
#undef sysFree
#undef sysMonitorSizeof
#undef sysMonitorEnter
#undef sysMonitorExit

extern void * sysMalloc(size_t);
extern void * sysRealloc(void*, size_t);
extern void sysFree(void*);
extern int sysMonitorEnter(sys_thread_t *tid, sys_mon_t *mid);
extern int sysMonitorExit(sys_thread_t *tid, sys_mon_t *mid);

#define jio_fprintf	fprintf

#define monitorEnter(A)		monitorEnter2(EE(),A)
#define monitorExit(A)		monitorExit2(EE(),A)
#define ResolveClassConstant(A,B,C,D) \
	ResolveClassConstant2(A, B, C, D, TRUE)
#define ResolveClassConstantFromClass(A,B,C,D) \
	ResolveClassConstantFromClass2(A, B, C, D, FALSE)
#define ObjAlloc(A,B) 		allocObject(EE(), A)
#define ArrayAlloc(A,B) 	allocArray(EE(), A, B)

#define dynoLink (jit_link->dynoLink)
#define getCustomInvoker (jit_link->getCustomInvoker)
#define invokeJNINativeMethod (jit_link->invokeJNINativeMethod)
#define invokeJNISynchronizedNativeMethod (jit_link->invokeJNISynchronizedNativeMethod)
#define invokeNativeMethod (jit_link->invokeNativeMethod)
#define invokeSynchronizedNativeMethod (jit_link->invokeSynchronizedNativeMethod)

#ifndef HAVE_EE
#define EE (jit_link->EE)
#endif
#ifndef HAVE_EXPANDJAVASTACK
#define ExpandJavaStack (jit_link->ExpandJavaStack)
#endif
#ifndef HAVE_EXPANDJAVASTACKFORJNI
#define ExpandJavaStackForJNI (jit_link->ExpandJavaStackForJNI)
#endif
#ifndef HAVE_INITCLASS
#define InitClass (jit_link->InitClass)
#endif
#ifndef HAVE_MULTIARRAYALLOC
#define MultiArrayAlloc (jit_link->MultiArrayAlloc)
#endif
#ifndef HAVE_RESOLVECLASSCONSTANT2
#define ResolveClassConstant2 (jit_link->ResolveClassConstant2)
#endif
#ifndef HAVE_RESOLVECLASSCONSTANTFROMCLASS2
#define ResolveClassConstantFromClass2 (jit_link->ResolveClassConstantFromClass2)
#endif
#ifndef HAVE_SIGNALERROR
#define SignalError (jit_link->SignalError)
#endif
#ifndef HAVE_VERIFYCLASSACCESS
#define VerifyClassAccess (jit_link->VerifyClassAccess)
#endif
#ifndef HAVE_ALLOCARRAY
#define allocArray (jit_link->allocArray)
#endif
#ifndef HAVE_ALLOCOBJECT
#define allocObject (jit_link->allocObject)
#endif
#ifndef HAVE_DO_EXECUTE_JAVA_METHOD_VARARG
#define do_execute_java_method_vararg (jit_link->do_execute_java_method_vararg)
#endif
#ifndef HAVE_INVOKEJAVAMETHOD
#define invokeJavaMethod (jit_link->invokeJavaMethod)
#endif
#ifndef HAVE_INVOKESYNCHRONIZEDJAVAMETHOD
#define invokeSynchronizedJavaMethod (jit_link->invokeSynchronizedJavaMethod)
#endif
#ifndef HAVE_IS_INSTANCE_OF
#define is_instance_of (jit_link->is_instance_of)
#endif
#ifndef HAVE_JIO_SNPRINTF
#define jio_snprintf (jit_link->jio_snprintf)
#endif
#ifndef HAVE_MONITORENTER2
#define monitorEnter2 (jit_link->monitorEnter2)
#endif
#ifndef HAVE_MONITOREXIT2
#define monitorExit2 (jit_link->monitorExit2)
#endif
#ifndef HAVE_SYSFREE
#define sysFree (jit_link->sysFree)
#endif
#ifndef HAVE_SYSMALLOC
#define sysMalloc (jit_link->sysMalloc)
#endif
#ifndef HAVE_SYSMONITORENTER
#define sysMonitorEnter (jit_link->sysMonitorEnter)
#endif
#ifndef HAVE_SYSMONITOREXIT
#define sysMonitorExit (jit_link->sysMonitorExit)
#endif
#ifndef HAVE_SYSREALLOC
#define sysRealloc (jit_link->sysRealloc)
#endif

#endif

extern JITlink const * jit_link;
extern struct methodblock *OpenJITcompileMB;
extern void *invokeCompiledCodeTable[];

extern bool_t OpenJIT_compile();
extern void OpenJIT_runtime_init(JITlink const *link, int * addr, int *attr);
extern void OpenJIT_resolveNativeMethod(struct methodblock *);
