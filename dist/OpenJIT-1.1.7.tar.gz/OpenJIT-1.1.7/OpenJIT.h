/*
 * Copyright (c) 1999 
 * Information Promotion Agency of Japan (IPA),
 * Fujitsu Limited, and 
 * Matsuoka Laboratory, Tokyo Institute of Technology
 * All rights reserved.
 *
 * Redistribution and non-commercial use in source and binary forms, 
 * with or without modification, are permitted provided that the following 
 * conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * 3. All advertising materials mentioning features or use of this 
 *    software must display the following acknowledgement:
 *
 *    This product includes software developed by Information Promotion Agency
 *    of Japan, Fujitsu Limited, and Matsuoka Laboratory, 
 *    Tokyo Institute of Technology.
 *
 * 4. The names "Information Promotion Agency", "Fujitsu Limited",
 *    "Matsuoka Laboratory", or "Tokyo Institute of Technology" should
 *    not be used to endorse or promote products derived from this
 *    software without specific prior written permission.
 *
 * 5. Any use of the source code or the binary in a commercial product, 
 *    whether may it be the origial representation or in some modified form,
 *    is not permitted without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * $Revision: 1.13 $
 * $Date: 1999/09/25 12:34:20 $
 * $Author: kouya $
 */

#include "mdconfig.h"

#include "bool.h"
#include "memory.h"
#include "oobj.h"
#include "interpreter.h"
#include "signature.h"
#include "tree.h"
#include "threads.h"
#include "exceptions.h"
#include "javaString.h"
#include "jmath.h"

#define OPENJITPKG "org/OpenJIT/"

/* support native thread. */
#define NATIVE_THREAD

/* in native thread, it might not work well? */
#define CODE_PATCH

/* resolve String at compile time for performace. */
#define RESOLVE_STRING_BEFOREHAND


struct compiled_CatchFrame {
    caddr_t start_pc, end_pc;	/* pc range of corresponding try block */
    caddr_t handler_pc;	        /* pc of catch handler */
};

/* methodblock->CompiledCodeFlags */
enum return_type {
    CCF_RETURN_VOID   = 0,
    CCF_RETURN_INT    = 1,
    CCF_RETURN_LONG   = 2,
    CCF_RETURN_FLOAT  = 3,
    CCF_RETURN_DOUBLE = 4,
};

#define RETURN_TYPE(mb)		(mb->CompiledCodeFlags & 0x7)

#define COMPILED_CODE_FLAGS_COMPILE_START	0x8
#define START_COMPILE(mb) \
	mb->CompiledCodeFlags |= COMPILED_CODE_FLAGS_COMPILE_START
#define COMPILE_ON_THE_WAY(mb) \
	((mb->CompiledCodeFlags & COMPILED_CODE_FLAGS_COMPILE_START) != 0)
#define FIX_ENTRY(mb) \
	((unsigned char *)&(mb->CompiledCodeFlags))[1] = 0xff;
#define ENTRY_IS_FIXED(mb) \
	(((unsigned char *)&(mb->CompiledCodeFlags))[1] != 0)

extern void *invokeCompiledCodeTable[];

extern JavaFrame *
OpenJIT_CompiledFramePrev(JavaFrame *frame, JavaFrame *buf);

extern void
OpenJIT_compile();

extern void
OpenJIT_Runtime_init();

/* JDK doesn't use EE arguments!!! */
#define IS_INSTANCE_OF(H, CB, EE)	is_instance_of(H, CB, NULL)

#if JDK_VERSION < 12
typedef struct {
    int *JavaVersion;

    void (**p_InitializeForCompiler)();
    void (**Vec_p_invokeCompiledMethod)();
    void (**p_CompiledCodeSignalHandler)();
    void (**p_CompilerFreeClass)();
    void (**p_CompilerCompileClass)();
    void (**p_CompilerCompileClasses)();
    void (**p_CompilerEnable)();
    void (**p_CompilerDisable)();
    void (**p_ReadInCompiledCode)();
    bool_t (**p_PCinCompiledCode)();
    unsigned char *(**p_CompiledCodePC)();
    char **p_CompiledCodeAttribute;
    bool_t *Vec_UseLosslessQuickOpcodes;

    void * (*sysMalloc)();
    void * (*sysCalloc)();
    void * (*sysRealloc)();
    void * (*sysFree)();

    ClassClass *** binclasses;
    int *nbinclasses;
    sys_mon_t **lock_classes;
    sys_mon_t **unlock_classes;

    ClassClass ** classJavaLangClass;
    ClassClass ** classJavaLangObject;
    ClassClass ** classJavaLangString;
    ClassClass ** classJavaLangThrowable;
    ClassClass ** classJavaLangException;
    ClassClass ** classJavaLangRuntimeException;
    ClassClass ** interfaceJavaLangCloneable;
    
    ExecEnv *(*EE)();
    void (*SignalError)();
    exception_t (*exceptionInternalObject)();

    char *(*GetClassConstantClassName)();
    bool_t (*ResolveClassConstant)();
    bool_t (*ResolveClassConstantFromClass)();
    bool_t (*VerifyClassAccess)();
    ClassClass *(*FindClass)();
    ClassClass *(*FindClassFromClass)();
    bool_t (*dynoLink)();
    long (*do_execute_java_method_vararg)();
    bool_t (*is_subclass_of)();
    
    bool_t (*invokeJavaMethod)();
    bool_t (*invokeSynchronizedJavaMethod)();
    bool_t (*invokeAbstractMethod)();
    bool_t (*invokeLazyNativeMethod)();
    bool_t (*invokeSynchronizedNativeMethod)();
    bool_t (*invokeCompiledMethod)();
	 
    void (*monitorEnter)();
    void (*monitorExit)();
    void (*monitorRegister)();
    int (*sysMonitorSizeof)();
    int (*sysMonitorEnter)();
    int (*sysMonitorExit)();
    
    HObject *(*ObjAlloc)();
    HObject *(*ArrayAlloc)();
    HObject *(*MultiArrayAlloc)();
    int (*sizearray)();
    HObject *(*newobject)();
    bool_t (*is_instance_of)();
    char *(*classname2string)();
    char *(*ID2Str)();
    void (*interfaceHash)();
    void (*DumpThreads)();
    
    JavaStack *(*CreateNewJavaStack)();
    long (*execute_java_static_method)();
    bool_t (*ExecuteJava)();
    
    long (*now)();
    int  *java_monitor;
    void (*java_mon)();
    long (*JavaStackSize)();
    
    JavaFrame *(**p_CompiledFramePrev)();
    int (*jio_snprintf)();
    char *(*javaString2CString)();
    
    bool_t (*dynoLinkJNI)();
    bool_t (*invokeNativeMethod)();
    
    jref (*jni_AddRefCell)();
    bool_t (*invokeJNINativeMethod)();
    bool_t (*invokeJNISynchronizedNativeMethod)();
    bool_t (*VerifyFieldAccess)();
} JITlink;

extern void OpenJIT_SignalHandler();
#else  /* JDK1.2 */
#include "jit.h"

typedef JITInterface6 JITlink;

extern bool_t OpenJIT_SignalHandler();

extern void *OpenJIT_CompiledFrameID(JavaFrame *frame);

extern JITlink *jit_link;

#define monitorEnter(key) monitorEnter2(EE(), key)
#define monitorExit(key) monitorExit2(EE(), key)

#define ResolveClassConstant(A,B,C,D) \
	(jit_link->ResolveClassConstant2)(A, B, C, D, TRUE)
#define ResolveClassConstantFromClass(A,B,C,D) \
	(jit_link->ResolveClassConstantFromClass2)(A, B, C, D, TRUE)
#define GetClassConstantClassName(A,B) \
	(jit_link->GetClassConstantClassName)(A, B)
#define ObjAlloc(A,B) \
	(jit_link->allocObject)(EE(), A)
#define ArrayAlloc(A,B) \
	(jit_link->allocArray)(EE(), A, B)
#define MultiArrayAlloc(A,B,C) \
	(jit_link->MultiArrayAlloc)(A,B,C)
#define sizearray(A,B) \
	(jit_link->sizearray)(A,B)
#define VerifyClassAccess(A,B,C) \
	(jit_link->VerifyClassAccess)(A,B,C)
#define SignalError(A,B,C) \
	(jit_link->SignalError)(A,B,C)
#define classname2string(A,B,C) \
	(jit_link->classname2string)(A,B,C)
#define is_instance_of(A,B,C) \
	(jit_link->is_instance_of)(A,B,C)
#define do_execute_java_method_vararg(A,B,C,D,E,F,G,H,I) \
	(jit_link->do_execute_java_method_vararg)(A,B,C,D,E,F,G,H,I)
#define jio_snprintf (jit_link->jio_snprintf)
#define monitorEnter2(A,B) \
	(jit_link->monitorEnter2)(A,B)
#define monitorExit2(A,B) \
	(jit_link->monitorExit2)(A,B)
#define ExpandJavaStack(A,B,C,D,E,F,G) \
	jit_link->ExpandJavaStack(A,B,C,D,E,F,G)
#define ExpandJavaStackForJNI(A,B,C,D) \
	jit_link->ExpandJavaStackForJNI(A,B,C,D)
#undef sysMonitorEnter(A,B)
#define sysMonitorEnter(A,B) \
	jit_link->sysMonitorEnter(A,B)
#undef sysMonitorExit(A,B)
#define sysMonitorExit(A,B) \
	jit_link->sysMonitorExit(A,B)
#define linkclass_lock \
	(jit_link->linkclass_lock)
#define invokeNativeMethod \
	(jit_link->invokeNativeMethod)
#define invokeSynchronizedNativeMethod \
	(jit_link->invokeSynchronizedNativeMethod)
#define InitClass(X) \
	jit_link->InitClass(X)
#define dynoLink(X,Y) \
	jit_link->dynoLink(X,Y)
#define invokeJNINativeMethod \
	jit_link->invokeJNINativeMethod
#define invokeJNISynchronizedNativeMethod \
	jit_link->invokeJNISynchronizedNativeMethod
#define getCustomInvoker(X) \
	jit_link->getCustomInvoker(X)
#define FindClass(A,B,C) \
	jit_link->FindClass(A,B,C)
#define monitorRegister(A,B) \
	jit_link->monitorRegister(A,B)
#define invokeJavaMethod \
	jit_link->invokeJavaMethod
#define invokeSynchronizedJavaMethod \
	jit_link->invokeSynchronizedJavaMethod

#undef sysMalloc
#undef sysRealloc
#undef sysFree
#undef sysMonitorSizeof
#define sysMalloc(X)	(jit_link->sysMalloc)(X)
#define sysRealloc(X,Y)	(jit_link->sysRealloc)(X,Y)
#define sysFree(X)	(jit_link->sysFree)(X)
#define sysMonitorSizeof()	(jit_link->sysMonitorSizeof)()

#define jio_fprintf	fprintf
#endif
